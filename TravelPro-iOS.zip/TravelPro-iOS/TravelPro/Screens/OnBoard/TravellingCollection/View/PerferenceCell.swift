//
//  PerferenceCell.swift
//  Todra
//
//  Created by Mac-OBS-18 on 23/02/22.
//

import UIKit

class PerferenceCell: UICollectionViewCell {
    @IBOutlet weak var lblPerference: UILabel!
    @IBOutlet weak var imgFlag: UIImageView!
    @IBOutlet weak var imgHeight: NSLayoutConstraint!
    @IBOutlet weak var imgWidth: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

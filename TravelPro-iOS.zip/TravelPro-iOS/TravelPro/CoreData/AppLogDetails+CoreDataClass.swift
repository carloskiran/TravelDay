//
//  AppLogDetails+CoreDataClass.swift
//  TravelPro
//
//  Created by Mac-OBS-32 on 08/05/23.
//
//

import Foundation
import CoreData

@objc(AppLogDetails)
public class AppLogDetails: NSManagedObject {

}

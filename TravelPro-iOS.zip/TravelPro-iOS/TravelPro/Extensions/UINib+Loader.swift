//
//  UINib+Loader.swift
//  MVVMSwiftExample
//
//  Created by Dino Bartosak on 26/09/16.
//  Copyright © 2016 Toptal. All rights reserved.
//

import UIKit

fileprivate extension UINib {
    
    static func nib(named nibName: String) -> UINib {
        return UINib(nibName: nibName, bundle: nil)
    }
    
    static func loadSingleView(_ nibName: String, owner: Any?) -> UIView {
        if let view = nib(named: nibName).instantiate(withOwner: owner, options: nil)[0] as? UIView {
            return view
        } else {
            return UIView()
        }
    }
}

// MARK: App Views

extension UINib {
    class func loadPlayerScoreboardMoveEditorView(_ owner: AnyObject) -> UIView {
        return loadSingleView("PlayerScoreboardMoveEditorView", owner: owner)
    }
}

//
//  MixpanelUserDetails.swift
//  TravelPro
//
//  Created by VIJAY M on 11/06/23.
//

import Foundation
import Mixpanel
